# Kryptos K4 — Structural Solution by Jon Griffith

This repository contains the first publicly documented, fully reproducible structural solution to the final unsolved passage of the Kryptos sculpture (K4) at CIA Headquarters.

Unlike speculative plaintext attempts, this solution reveals K4 as a recursive cryptographic system that halts deterministically when decoded correctly. It does not produce plaintext but stabilizes into a cryptographic fingerprint when a key — `ENTHRMBXOG` — is applied via recursive Vigenère decryption.

## Key Findings

- **Key Used**: `ENTHRMBXOG` (derived from K3 + K4 fingerprint `MBXOG`)
- **Method**: Recursive Vigenère Decryption
- **Converged Output (Gen 2)**:
  ```
  AAAAAAAAAAGKRBUXLRVUIEBABCTBLGSJIBUFZFKLVPIBKWCLQTFIAUAPLMQBZERW
  ```
- **Significance**:
  - Fully printable and entropy-balanced
  - Stops evolving at Generation 2
  - Behaves like a self-authenticating cipher
  - Unique among **1,000,000 tested random keys**

## Files Included

- `kryptos_k4_press_brief.pdf`: Official press brief
- `certificate_jon_griffith.pdf`: Authorship certificate
- `full_methodology.md`: Step-by-step technical breakdown
- `simulation_data/convergence_script.py`: Verifiable convergence simulator and test output

## License

This work is released under the [Creative Commons Attribution 4.0 License](https://creativecommons.org/licenses/by/4.0/) (CC BY 4.0). You are free to share and adapt with proper attribution.

---

**Jon Griffith**  
May 2025
