import random
import string

def vigenere_decrypt(text, key):
    decrypted = []
    key = key.upper()
    for i, c in enumerate(text):
        shift = ord(key[i % len(key)]) - ord('A')
        decrypted.append(chr((ord(c) - ord('A') - shift) % 26 + ord('A')))
    return ''.join(decrypted)

def generate_random_key(length=10):
    return ''.join(random.choices(string.ascii_uppercase, k=length))

def test_convergence(ciphertext, trials=1000):
    converged = 0
    for _ in range(trials):
        key = generate_random_key()
        first = vigenere_decrypt(ciphertext, key)
        second = vigenere_decrypt(ciphertext, first[:10])
        if first == second:
            converged += 1
    return converged

if __name__ == "__main__":
    k4 = "OBKRUOXOGHULBSOLIFBBWFLRVQQPRNGKSSOTWTQSJQSSEKZZWATJKLUDIAWINFBNYPVTTMZFPKWGDKZXTJCDIGKUHUAUEKCAR"
    print("Convergences:", test_convergence(k4, 10000))
